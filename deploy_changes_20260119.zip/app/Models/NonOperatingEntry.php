<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class NonOperatingEntry extends Model
{
    protected $fillable = [
        'accounting_period_id',
        'client_id',
        'type',
        'category',
        'description',
        'amount',
        'tax_rate',
        'tax_amount',
        'notes',
    ];

    protected $casts = [
        'amount' => 'decimal:2',
        'tax_rate' => 'decimal:2',
        'tax_amount' => 'decimal:2',
    ];

    public function accountingPeriod()
    {
        return $this->belongsTo(AccountingPeriod::class);
    }

    public function client()
    {
        return $this->belongsTo(Client::class);
    }
}
